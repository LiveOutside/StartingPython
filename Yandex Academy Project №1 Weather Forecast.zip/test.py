import sys
from datetime import datetime
from pyowm.owm import OWM
from pyowm.utils import config, timestamps
from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5 import QtGui, QtCore
from PyQt5.QtCore import Qt


GLOBAL_STATE = 0


def to_fixed(num, digits=0):
    return f'{num:.{digits}f}'


City = input('Введите город: ')

Weather_Conditions = {
    'clouds': 'icons/cloudy.png',
    'rain': 'icons/rain.png',
    'drizzle': 'icons/drizzle.png',
    'mist': 'icons/fog.png',
    'smoke': 'icons/fog.png',
    'haze': 'icons/fog.png',
    'dust': 'icons/fog.png',
    'sand': 'icons/fog.png',
    'ash': 'icons/fog.png',
    'squall': 'icons/fog.png',
    'tornado': 'icons/tornado.png',
    'thunderstorm': 'icons/thunder.png',
    'snow': 'icons/snow.png',
}

config_dict = config.get_config_from('configs/owmconfig.json')

owmKey = OWM('c6514e4959626a2e6eca7fa05db91fc7', config_dict)

# ПРОГНОЗ ПОГОДЫ НА СЕГОДНЯ
Manager = owmKey.weather_manager()
Observation = Manager.weather_at_place(City)
Weather = Observation.weather
# ТЕМПЕРАТУРА
temperature_request = Weather.temperature('celsius')
temperature = temperature_request['temp']
feels_like_temperature = temperature_request['feels_like']
max_temperature = temperature_request['temp_max']
min_temperature = temperature_request['temp_min']
# СОСТОЯНИЕ ПОГОДЫ
humidity = Weather.humidity
wind_speed = Weather.wind()['speed']
clouds = Weather.clouds
weather_status = Weather.status
detailed_weather_status = Weather.detailed_status
pressure = Weather.pressure['press']

# # ПРОГНОЗ ПОГОДЫ НА ЗАВТРА
# tomorrow = timestamps.tomorrow(datetime.now().hour, datetime.now().minute)
# forecast = Manager.forecast_at_place(City, '3h')
# tomorrow_forecast = forecast.get_weather_at(tomorrow)
# # ТЕМПЕРАТУРА
# tomorrow_temperature_request = tomorrow_forecast.temperature('celsius')
# tomorrow_temperature = tomorrow_temperature_request['temp']
# # СОСТОЯНИЕ ПОГОДЫ
# tomorrow_clouds = tomorrow_forecast.clouds
# tomorrow_detailed_weather_status = tomorrow_forecast.detailed_status
#
# # ПРОГНОЗ ПОГОДЫ НА ВЧЕРА
# yesterday = timestamps.yesterday(datetime.now().hour, datetime.now().minute)
# yesterday_forecast = forecast.get_weather_at(yesterday)
# # ТЕМПЕРАТУРА
# yesterday_temperature_request = yesterday_forecast.temperature('celsius')
# yesterday_temperature = yesterday_temperature_request['temp']
# # СОСТОЯНИЕ ПОГОДЫ
# yesterday_clouds = yesterday_forecast.clouds
# yesterday_detailed_weather_status = yesterday_forecast.detailed_status


class WeatherForecast(QMainWindow):
    def __init__(self):
        super(WeatherForecast, self).__init__()
        uic.loadUi('uics/WeatherForecastReady.ui', self)

        #self.button_maximize.clicked.connect(lambda: maximize_restore())
        self.button_minimize.clicked.connect(lambda: self.showMinimized())
        self.button_close.clicked.connect(lambda: self.close())

        self.setWindowFlag(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        # MAIN INFO
        self.temperature_label.setText(str(to_fixed(temperature, 1)) + '°')
        self.city_label.setText(City.capitalize())

        # ADDITIONAL INFO
        self.wind_label.setText(str(wind_speed) + ' м/с')
        self.humidity_label.setText(str(humidity))
        self.feels_like_label.setText(str(round(feels_like_temperature)) + '°')
        self.pressure_label.setText(str(pressure) + ' мм.')

        # # YESTERDAY INFO
        # self.yesterday_time_label.setText(str(datetime.now().hour) + ':' + str(datetime.now().minute))
        # self.yesterday_temperature_label.setText(str(yesterday_temperature) + '°')
        #
        # # TOMORROW INFO
        # self.tomorrow_time_label.setText(str(datetime.now().hour) + ':' + str(datetime.now().minute))
        # self.tomorrow_time_label.setText(tomorrow_temperature)

        if weather_status.lower() in Weather_Conditions:
            self.main_image_label.setPixmap(QtGui.QPixmap(Weather_Conditions[weather_status.lower()]))

        elif weather_status.lower() == 'clear':
            if datetime.now().hour >= 24:
                self.main_image_label.setPixmap(QtGui.QPixmap('icons/night/moon.png'))
            else:
                self.main_image_label.setPixmap(QtGui.QPixmap('icons/day/sun.png'))

        #  КНОПКА РАСКРЫТИЯ, ПОКА ЧТО НЕ ВИЖУ В НЕЙ СМЫСЛА
        # def maximize_restore():
        #     global GLOBAL_STATE
        #     window_status = GLOBAL_STATE
        #     if window_status == 0:
        #         self.showMaximized()
        #
        #         GLOBAL_STATE = 1
        #         self.main_layout.setContentMargins(0, 0, 0, 0)
        #         self.main_layout.setStyleSheet("background-color: rgb(255, 255, 255);
        #         color: rgb(0, 0, 0); border-radius: 35px;")
        #         self.button_maximize.setToolTip("Restore")
        #     else:
        #         GLOBAL_STATE = 0
        #         self.showNormal()
        #         self.resize(self.width() + 1, self.height() + 1)
        #         self.main_layout.setContentMargins(10, 10, 10, 10)
        #         self.main_layout.setStyleSheet("background-color: rgb(255, 255, 255);
        #         color: rgb(0, 0, 0); border-radius: 35px;")
        #         self.button_maximize.setToolTip("Maximize")

        def window_move(event):
            if event.buttons() == Qt.MouseButton.LeftButton:
                self.move(self.pos() + event.globalPos() - self.dragPos)
                self.dragPos = event.globalPos()
                event.accept()

        self.title_bar.mouseMoveEvent = window_move

    def mousePressEvent(self, event):
        self.dragPos = event.globalPos()




# ДЛЯ ПРОВЕРКИ
print(f'В городе {City}, температура {temperature}, ощущается как {feels_like_temperature}, минимальная {min_temperature}, максимальная {max_temperature}. '
      f'Влажность: {humidity}, скосроть ветра {wind_speed}, облачность {clouds}, давление {pressure}'
      f'статус погоды {weather_status}, детальный статус погоды {detailed_weather_status}')


if __name__ == '__main__':
    app = QApplication(sys.argv)
    win = WeatherForecast()
    win.setFixedWidth(380)
    win.setFixedHeight(700)
    win.show()
    sys.exit(app.exec())







